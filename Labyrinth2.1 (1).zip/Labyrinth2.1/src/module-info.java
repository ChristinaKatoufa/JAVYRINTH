module Labyrinth {
	requires java.desktop;
}