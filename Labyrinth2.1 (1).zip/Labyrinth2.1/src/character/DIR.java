package character;

public enum DIR {

	N, S, W, E, O; // North, South, East, West, O : point zero
}
