package main;

/**
 * @authors ChristinaKatoufa, GavrilakiMarina
 */
public class Main {

    public static void main(String[] args) {

        new GameWindow();


    }
}
